# Flags

Adds decorative flags for marking areas or displaying heraldry.

This is the core mod, and does not add additional logos from Patreon rewards.

![Preview](https://raw.githubusercontent.com/cuproPanda/Flags/master/About/Preview.png)